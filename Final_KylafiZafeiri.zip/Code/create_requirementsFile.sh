# pip install pipreqs
pipreqs --force

# Previous Requirements:
# beautifulsoup4==4.9.3
# liwc==0.5.0
# nltk==3.6.1
# pandas==1.2.4
# requests==2.25.1
# sympy==1.8
# regex==2021.4.4
